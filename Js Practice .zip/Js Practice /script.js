// form validation
var name_error = document.getElementById('nameerror');
var phonenumber_error = document.getElementById('phoneerror');
var email_error = document.getElementById('emailerror');
var pass_error = document.getElementById('passerror');

function validatename() {
    var name = document.getElementById('name').value;

    // Check if name is empty
    if (name.length === 0) {
        name_error.innerHTML = 'Name is required';
        return false;
    }

    // Check if name matches the "First Last" pattern
    if (!name.match(/^[A-Za-z]+\s[A-Za-z]+$/)) {
        name_error.innerHTML = 'Write full name';
        return false;
    }

    // If validation passes
    name_error.innerHTML = 'Valid';
    return true;
}

function validatephone() {
    var phone = document.getElementById('phone_number').value;

    // Check if the phone number is empty
    if (phone.length === 0) {
        phonenumber_error.innerHTML = 'Phone number is required';
        return false;
    }

    // Check if the phone number is exactly 10 digits long and contains only digits
    if (!/^\d{10}$/.test(phone)) {
        phonenumber_error.innerHTML = 'Phone number must be exactly 10 digits';
        return false;
    }

    // If validation passes
    phonenumber_error.innerHTML = 'Valid';
    return true;
}


function validateemail (){
    var email = document. getElementById('email') . value;
    if(email.length == 0)
    {
        email_error. innerHTML = 'Email is required'
        return false;
    }
    if (!email.match(/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/)) {
        email_error.innerHTML = 'Invalid email format';
        return false;
    }
        email_error. innerHTML = 'valid';
        return true;
}
function validateform()
{
    if(!validatename() || !validateform() || !valid())
    {

    }
} 

// API 

var search = document.querySelector('.search');
var search_button = document.querySelector('.btn_search');
var recipes = document.querySelector('.main');

//prevent default is a function for stoping the page from reloading 

var fetch_data = async (input) => {
    var data = await fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${input}`);
    var ans = await data.json();

    // Clear previous results
    recipes.innerHTML = '';

    if (ans.meals) {
       // console.log(ans.meals[0]);
        ans.meals.forEach(meal => {
           
            var recipesmealdiv = document.createElement('div');
            recipesmealdiv.classList.add('meal');
           
            recipesmealdiv.innerHTML = `
                <img src="${meal.strMealThumb}" alt="${meal.strMeal}" class="meal-img">
                <h1 class="name">${meal.strMeal}</h1>
                <h3 class="cate_name">${meal.strCategory}</h3>
                
            `;            
            recipes.appendChild(recipesmealdiv);

            // decrease the size of the long name.
            var nameElement = recipesmealdiv.querySelector('.name');
            if (meal.strMeal.length > 35) {
                nameElement.style.fontSize = '12px'; // Decrease font size
            }
            
        });
       // recipes.style.backgroundColor = "red"; // Corrected property
       
        
    } else {
        recipes.innerHTML = `<p class="errormessage">No results found for ${input}  😢</p>` // Show a message if no meals are found
    }

    
};

search_button.addEventListener('click',(e)=>{
    e.preventDefault();
    //trim function is used to remove spaces from the input
    var input =  search.value.trim();
    fetch_data(input);
});